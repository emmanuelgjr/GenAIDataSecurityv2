## Summary

## Scope of Change

## Definition of Done
- [ ] ≤150-word summary
- [ ] MUST/SHOULD/MAY controls
- [ ] Tests/audit steps
- [ ] Mappings updated (/docs/appendices/C-mappings-nist-iso-atlas.md)
- [ ] References
- [ ] ADR if architectural

## Reviewer Notes
