# Security Policy

Please report sensitive security issues privately via email to the maintainers.
Do not post proofs-of-concept that may expose live systems or sensitive data in public issues.
