# Appendix A — Controls Catalog (Index)

Use IDs like CTRL-ENC-01, CTRL-AC-02, CTRL-OUT-03, AGT-01..12.
For each:
- Purpose
- Normative statement
- Config examples/snippets
- Tests/audit evidence
