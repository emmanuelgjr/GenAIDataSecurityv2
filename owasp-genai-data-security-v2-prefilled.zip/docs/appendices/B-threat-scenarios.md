# Appendix B — Threat Scenarios

- Prompt policy override → data leakage via tool chain
- Poisoned embeddings in vector DB
- Rogue plugin exfiltration
For each: kill chain, controls, detections, response.
