# Appendix D — Glossary

Key terms: Agent, Vector Store, PETs, Differential Privacy, Confidential Computing, SLSA, SBOM, Policy-as-Code.
