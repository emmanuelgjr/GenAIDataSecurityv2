# Traditional vs. LLM-Specific Data Security

**Summary:** Refreshes baseline controls (encryption, IAM, DLP) and extends to LLM specifics (prompt/input/output handling, model/data poisoning, vector-store security).

**Controls (MUST/SHOULD/MAY)**
- MUST: Encrypt data in transit (TLS 1.3+) and at rest (AES-256 or stronger); enforce MFA and least privilege.
- SHOULD: Confidential computing for sensitive transforms; PETs for privacy-respecting analytics.
- MAY: PQC pilots for long-lived secrets.

**Tests**
- Verify TLS ciphers; key rotation logs; DLP policy enforcement.
