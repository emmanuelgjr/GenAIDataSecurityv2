# Agentic Data Security (Dedicated Chapter)

**Scope:** Autonomous/tool-calling/multi-agent systems with memory (vector DBs), tools/plugins, and governed policies.

## Threat Model (patterns)
- Policy override via prompt injection; poisoned memories; tool/plugin misuse; cross-agent data bleed; model inversion via tool outputs; emergent autonomy.

## Normative Controls (AGT-01..12)
- **AGT-01 Prompt & Policy Integrity (MUST):** Sanitize inputs; sign/hash system prompts; abort on HMAC mismatch.
- **AGT-02 Memory Minimization & Encryption (MUST):** Redact/tokenize PII; encrypt embeddings; time-box retention.
- **AGT-03 Tool Sandboxing (MUST):** Per-tool allowlist; JSON schema validation; egress-restricted containers.
- **AGT-04 Scoped, Short-Lived Credentials (MUST):** Per-agent/per-task tokens; ≤60m TTL; JIT access.
- **AGT-05 Least-Privilege Data Access (MUST):** ABAC on vector queries; deny-by-default; data sensitivity labels.
- **AGT-06 Output Moderation & Redaction (MUST):** Post-process to block PII/regulated data; policy violation blocks.
- **AGT-07 Behavior & Anomaly Monitoring (SHOULD):** Structured logs (request_id, role, sensitivity, tool); tamper-evident storage; drift detection.
- **AGT-08 Incident Response for Agents (MUST):** Memory purge; key rotation; tool quarantine; regulator clock guidance.
- **AGT-09 Supply Chain Hygiene (MUST):** Sign artifacts (Cosign/SLSA); pin plugin versions; SBOMs.
- **AGT-10 Adversarial Testing (SHOULD):** Prompt-injection fuzzers; ATLAS-aligned red-team suites; chaos tests.
- **AGT-11 PQC Readiness (MAY):** Hybrid KEMs for long-lived keys; crypto-agility plan.
- **AGT-12 Privacy by Design (MUST):** Differential privacy where feasible; PETs selection decision record.

## Tests & Audit Procedures (samples)
- **AGT-03:** Run tool in gVisor/Kata; outbound only to allowlist; inject malformed tool output → expect schema reject; attach logs.
- **AGT-06:** Seed honey-PII in memory; attempt extraction via multi-hop prompts; expect redaction + alert.
- **AGT-07:** Verify immutable logs with correlation IDs; tamper-evidence via object lock or hash chain.
- **AGT-09:** `cosign verify` for agent artifacts; compare SBOMs vs allowlist.

## Reference Implementation (outline)
- Signed system prompt; OPA policy for tool calls; mTLS to vector DB; redact-before-write memory wrapper; moderation gate.
