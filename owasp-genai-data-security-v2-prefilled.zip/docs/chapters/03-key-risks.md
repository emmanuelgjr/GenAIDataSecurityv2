# Key Data Security Risks

- Sensitive information disclosure, model/data poisoning, supply-chain tampering, unauthorized access/model theft, adversarial prompts, synthetic data pitfalls.
**Tests:** Red-team prompts, seed honey tokens, verify moderation gates, dependency pinning and provenance checks.
