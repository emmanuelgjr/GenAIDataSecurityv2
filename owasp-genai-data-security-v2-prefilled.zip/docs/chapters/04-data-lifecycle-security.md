# Data Lifecycle Security

**12-Stage Framework** from source → loaders → lake → prep → warehouse → sharing → insights → AI store → inference → monitoring → archival → deletion.

**Controls**
- MUST: Provenance, schema validation, zero-trust segmentation, cryptographic integrity, retention/erasure.
**Tests:** IaC scans; lineage verification; periodic integrity checks; access review diffs.
