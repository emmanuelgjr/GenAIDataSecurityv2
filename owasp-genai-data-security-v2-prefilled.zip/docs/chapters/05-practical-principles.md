# Practical Principles & Controls

Convert principles into **control IDs** with audit steps. Example:
- CTRL-ENC-01 (MUST): KMS-managed keys; envelope encryption.
- CTRL-AC-02 (MUST): ABAC/RBAC with SoD; JIT access.
- CTRL-OUT-03 (MUST): Output moderation/redaction before delivery.
**Tests:** Config screenshots/snippets + reproducible scripts.
