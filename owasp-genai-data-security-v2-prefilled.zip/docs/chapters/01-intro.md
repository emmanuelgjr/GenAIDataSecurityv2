# Introduction

**Purpose (≤150 words):** This document provides normative, testable best practices for GenAI/LLM data security, including a dedicated Agentic Data Security chapter. It is a living, community-led resource with release tags and ADR-managed decisions.

**WHAT'S NEW IN v2**
- Normative control catalog with audit procedures
- Dedicated Agentic Data Security chapter
- Expanded monitoring/auditing runbooks and KPIs
- Centralized framework mappings

**DoD Evidence**
- Summary: ✓
- Controls: See chapters
- Mappings: See appendices
- Tests: See per-control procedures
- References: Inline
