# Monitoring, Auditing & Runbooks

**Cadence:** Weekly → Monthly → Quarterly → Annual, risk-based.
**Runbooks:** Anomaly playbook; policy violation triage; credential leakage response.
**KPIs:** MTTD for policy violations, % blocked extractions, key-rotation compliance.
