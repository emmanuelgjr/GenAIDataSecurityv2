# Future Trends & Open Questions

Agent swarms, on-device LLMs, PQC migration, sector overlays. Community RfCs for gaps and emerging attacks.
